# Landing Page Project
this project to test my skills to program in Java Script, to create a navigation menu that scroll sections smoothly and each section will be set to active state one it is located inside the viewport.
## Table of Contents
- Builing Navigation Menu in JS by looping for section element and built Nav Manue based on it.
- Build actions linked to each button in the nav menu, once clicked it scrolls the section to the viewport area
- Activate section and menu button when section is scrolling near to top

* [Instructions](#instructions)
- `DOMContentLoaded` listner added to ensure creating nav menu and assigning their action without conflict with DOM building structure as JS inserted before the body creation in HTML file.
- `menuNavClicked` is the function linked to event listner.

## Contents
_The project contains the following files:_
```
- index.html
- README.md
- styles.css
- app.js
```